black_pixel = (0, 0, 0, 255)
white_pixel = (255, 255, 255, 255)
