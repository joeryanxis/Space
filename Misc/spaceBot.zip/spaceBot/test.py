import random


imgNum = random.randrange(180)
print(imgNum)

num = random.uniform(.6, 1.8)
print(num)